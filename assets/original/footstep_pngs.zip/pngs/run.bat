@echo off

ren "footstep_0000_Layer-18.png" "footstep_18.png"
ren "footstep_0001_Layer-17.png" "footstep_17.png"
ren "footstep_0002_Layer-16.png" "footstep_16.png"
ren "footstep_0003_Layer-15.png" "footstep_15.png"
ren "footstep_0004_Layer-14.png" "footstep_14.png"
ren "footstep_0005_Layer-13.png" "footstep_13.png"
ren "footstep_0006_Layer-12.png" "footstep_12.png"
ren "footstep_0007_Layer-11.png" "footstep_11.png"
ren "footstep_0008_Layer-10.png" "footstep_10.png"
ren "footstep_0009_Layer-9.png"  "footstep_09.png"
ren "footstep_0010_Layer-8.png"  "footstep_08.png"
ren "footstep_0011_Layer-7.png"  "footstep_07.png"
ren "footstep_0012_Layer-6.png"  "footstep_06.png"
ren "footstep_0013_Layer-5.png"  "footstep_05.png"
ren "footstep_0014_Layer-4.png"  "footstep_04.png"
ren "footstep_0015_Layer-3.png"  "footstep_03.png"
ren "footstep_0016_Layer-2.png"  "footstep_02.png"
ren "footstep_0017_Layer-1.png"  "footstep_01.png"

pause